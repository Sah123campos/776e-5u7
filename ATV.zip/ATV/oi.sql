-- 1)Liste os nomes dos funcionários cujos nomes de departamento contêm a palavra "Recursos Humanos" (estude o operador LIKE).
select nome_funcionario from funcionario 
where sigla_depto in (select sigla_depto
from departamento 
where nome_depto like '%ecursos Humano%');

-- 2)Liste os nomes dos funcionários que estão trabalhando em projetos do departamento contidos em 'MKT' e também 'RH'.

select nome_funcionario from funcionario
where sigla_depto = (select sigla_depto from departamento
where sigla_depto like '%K%' AND '%%');

-- 3)Liste os nomes dos departamentos e a soma dos salários de todosos funcionários em cada departamento (estude o operador SUM).
select nome_depto from departamento
select (sum(salario) from funcionario);

-- 4)Liste os nomes dos funcionários que trabalham em projetos do departamento 'TI' e que ganham mais do que a média salarial dos funcionários do departamento 'TI' (estude o operador AVG).
 
 
 -- 5)Liste os nomes dos departamentos e a quantidade de funcionários em cada departamento (estude o operador COUNT).
 select nome_depto 